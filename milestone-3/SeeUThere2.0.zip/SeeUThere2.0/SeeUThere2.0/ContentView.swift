//
//  ContentView.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Search()
                .tabItem() {
                    Image(systemName: "imageName.png")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 10, height: 10)
                    Text ("Search")
                }
            UserPage()
                .tabItem() {
                    Image("logotransparent")
                        .resizable()
                        .frame(width: 1, height: 1)
                    Text ("User")
                }
            Calendar()
                .tabItem(){
                    Image(systemName: "imageName.png")
                    Text ("Calendar")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
