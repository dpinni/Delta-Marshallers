//
//  Calendar.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct Calendar: View {
    var body: some View {
        ZStack {
            Color.blue
        }
    }

}

struct Calendar_Previews: PreviewProvider{
    static var previews: some View{
        Calendar()
    }
}

