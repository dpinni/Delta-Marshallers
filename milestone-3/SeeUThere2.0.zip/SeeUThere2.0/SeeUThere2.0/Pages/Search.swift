//
//  Search.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct Search: View {
    var body: some View {
        ZStack {
            Color.green
        }
    }

}

struct Search_Previews: PreviewProvider{
    static var previews: some View{
        Search()
    }
}

