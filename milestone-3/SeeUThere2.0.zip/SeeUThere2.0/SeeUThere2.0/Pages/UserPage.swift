//
//  UserPage.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct UserPage: View {
    var body: some View {
        ZStack {
            Color.red
            
            Image("aaron-slaven.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .position(x: 100, y: 100)
                //.clipShape(Circle())
        }
    }

}

struct UserPage_Previews: PreviewProvider{
    static var previews: some View{
        UserPage()
    }
}
