//
//  ContentView.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        //.ignoresSafeArea(self)
            TabView {
                Search()
                    .tabItem() {
                        Image("searchIcon")
                        Text ("Search")
                    }
                UserPage()
                    .tabItem() {
                        Image("icon")
                    }
                
                Calendar()
                    .tabItem(){
                        Image("calendarIcon")
                        Text ("Calendar")
                    }
            }
            .toolbarBackground(.hidden, for: .tabBar)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
        ContentView()
    }
}
