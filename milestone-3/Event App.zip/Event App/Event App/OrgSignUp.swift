//
//  UserSignUp.swift
//  Event App
//
//  Created by Clare Rizzo on 3/5/24.
//

import SwiftUI

struct OrgSignUp: View {
    @State var labelWidth: CGFloat? = nil

    @State var username = ""
    @State var password = ""
    @State var email = ""
    @State var firstName = ""
    @State var lastName = ""
    @State var orgName = ""
    @State var orgType = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                just_logo()
                    .padding(50)
            }
            TextField("Email", text: $email)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Password", text: $password)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Confirm Password", text: $password)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("First Name", text: $firstName)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Last Name", text: $lastName)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Organization Name", text: $orgName)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Organization Type", text: $orgType)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            Spacer()
            VStack {
                Spacer()
                NavigationLink("Create Account", destination: HomePage())
                    
                    .frame(width: 200, height: 50)
                    .foregroundColor(.white)
                    .background(.green)
                    .cornerRadius(20.0)
            }
            
        }
    }
}

#Preview {
    OrgSignUp()
}

