////
////  FriendsView.swift
////  Event App
////
////  Created by Clare Rizzo on 3/14/24.
////
//
//import SwiftUI
//
//struct Friends: Identifiable {
//    var id:UUID = UUID()
//    var name:String
//    var mutualFriends:Int
//    var avatar:String
//    var poster: String
//    
//    
//}
//
//struct FriendsView: View {
//    
//    var friends:[Friends] = [
//        Friends(name: "Kristina", mutualFriends: 30, avatar: "kristina", poster: "img1"),
//        Friends(name: "Robert", mutualFriends: 30, avatar: "robert", poster: "img2"),
//        Friends(name: "Dave", mutualFriends: 30, avatar: "dave", poster: "img3"),
//        Friends(name: "Hector", mutualFriends: 30, avatar: "hector", poster: "img4"),
//        Friends(name: "Kelly", mutualFriends: 30, avatar: "kelly", poster: "img5"),
//        
//    ]
//    
//    
//    var body: some View {
//        NavigationView {
//            ScrollView {
//                ForEach(friends, id: \.id) { friends in
//                    HStack {
//                        Image(friends.avatar)
//                            .resizable()
//                            .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
//                            .clipped()
//                            .clipShape(Circle())
//                            .frame(width: 80, height: 80)
//                        VStack (alignment: .leading, spacing: 10) {
//                            VStack (alignment: .leading, spacing: 2) {
//                                Text(friends.name)
//                                Text("\(friends.mutualFriends) mutual friends")
//                            }
//                            HStack {
//                                Button(action: {
//                                    print("add friend")
//                                }) {
//                                    ZStack {
//                                        RoundedRectangle(cornerRadius: 5)
//                                            .frame(height: 35)
//                                            .foregroundColor(.blue)
//                                        Text("add friend")
//                                            .font(.system(size: 13))
//                                            .foregroundColor(.white)
//                                    }
//                                    
//                                }
//                                Button(action: {
//                                    print("remove friend")
//                                }) {
//                                    ZStack {
//                                        RoundedRectangle(cornerRadius: 5)
//                                            .frame(height: 35)
//                                            .foregroundColor(.gray)
//                                        Text("remove friend")
//                                            .font(.system(size: 13))
//                                            .foregroundColor(.white)
//
//                                    }
//                                    
//                                }
//                                Spacer()
//                            }
//                        }
//                    }
//                }.navigationBarTitle("Friends")
//            }
//        }
//    }
//}
//
//struct FriendsView_Previews: PreviewProvider {
//    static var previews: some View {
//        FriendsView()
//    }
//}
//    
