//
//  UserPage.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI
import PhotosUI

struct Event: Identifiable{
    @State var id:UUID = UUID()
    @State var imageTitle:String
    @State var imageName:String
    @State var location:String
    
}

struct UserPage: View {
    @State private var progress = 0.0
    @State private var isOverlay = false
    @State private var selectedImage: String?
    @State private var searchText = ""
    
    @State private var avatarItem: PhotosPickerItem? = nil
    //@State private var avatarImage: Data? = nil
    
    @State var events:[Event] = [
        Event(imageTitle: "Horseback Riding", imageName: "horsebackRiding", location: "field" ),
        Event(imageTitle: "Painting Class", imageName: "paintingClass", location: "art studio" ),
        Event(imageTitle: "Concert", imageName: "concert", location: "stage" ),
        Event(imageTitle: "Ice Cream", imageName: "iceCream", location: "ice cream shop" ),
        Event(imageTitle: "Biking", imageName: "biking", location: "park" ),
        Event(imageTitle: "Weightlifting", imageName: "weightlifting", location: "gym" )
        ]
    
    var filteredEvents: [Event] {
        if searchText.isEmpty {
            return events
        } else {
            return events.filter { $0.imageTitle.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    @EnvironmentObject var userData: SharedData
    
    
    
    var body: some View {
        NavigationView{
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color("treeGreen"), Color(.white)]), startPoint: .top, endPoint: .bottom).opacity(0.5).ignoresSafeArea()
                
                if let selectedPhotoData = userData.selectedPhotoData,
                   let image = UIImage(data: selectedPhotoData) {
                    Image(uiImage: image)
                        .resizable()
                        .frame(width: 125, height: 125)
                        .clipShape(Circle())
                        .frame(width: 1, height: 1)
                        .position(x: 85, y: 75)
                }
                else {
                    Image(systemName: "camera")
                     .resizable()
                     .frame(width: 95, height: 75)
                     .padding(20)
                     .background(.gray.opacity(0.4))
                     .clipShape(Circle())
                     .frame(width: 1.0, height: 1.0)
                     .position(x: 75, y: 75)
                }
                
                PhotosPicker(selection: $avatarItem, matching:.any(of:[.images, .not(.livePhotos)])) {
                    Image(systemName: "camera")
                        .resizable()
                        .frame(width: 95, height: 75)
                        .padding(20)
                        .background(.gray.opacity(0.4))
                        .clipShape(Circle())
                        .frame(width: 1.0, height: 1.0)
                        .position(x: 75, y: 75)
                }
                .position(x: 200, y: 10)
                .onChange(of: avatarItem){ newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self){
                            userData.selectedPhotoData = data
                        } else {
                            print("Failed")
                        }
                    }
                }
                
                
                VStack (alignment: .leading, spacing: 6){
                    Text("Welcome")
                        .font(.system(size: 25))
                        .foregroundColor(Color("forrestGreen"))
                    
                    Text(userData.fullName)
                        .frame(width: 200, height: 75, alignment: .topLeading)
                    //.scaledToFill()
                        .font(.system(size: 35))
                        .fontWeight(.bold)
                        .foregroundColor(Color("forrestGreen"))
                    
                    Spacer()
                    
                }
                .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
                .position(x:355, y: 400)
                
                ProgressView(value: progress) { Text("Level \(String(format: "%.0f", progress))")}
                    .padding(15)
                    .cornerRadius(4)
                    .frame(width: 370, height: 100)
                    .position(x:200, y: 160)
                    .foregroundColor(Color("forrestGreen"))
                    .font(.system(size: 20))
                
                NavigationLink(destination: ProfilePage()) {
                    Image("profileFiller")
                        .resizable()
                        .frame(width: 50, height: 50)
                }
                .position(x: 335, y: 60)
                
                NavigationLink(destination: QRView()) {
                    Image("scan_icon")
                        .resizable()
                        .frame(width: 50, height: 50)
                }              
                .position(x: 335, y: 120)
                
                ScrollView{
                    VStack (spacing: 20){
                        SearchBar(text: $searchText)
                            .position(x: 217, y: 40)
                        //.showsCancelButton = false
                        
                        ForEach(filteredEvents, id: \.id){
                            events in
                            Image(events.imageName)
                                .resizable()
                                .frame(width: 335, height: 250)
                                .onTapGesture {
                                    selectedImage = events.imageName
                                    isOverlay = true
                                }
                                .overlay(
                                    VStack{
                                        if events.imageName == selectedImage && isOverlay {
                                            
                                            Text("")
                                                .frame(width: 336, height: 250)
                                                .background(.white.opacity(0.8))
                                                .position(x:167, y:125)
                                                .overlay(
                                                    VStack{
                                                        Text(events.imageTitle)
                                                            .frame(width: 300, height: 100, alignment: .topLeading)
                                                            .bold()
                                                            .font(.system(size: 20))
                                                            .foregroundStyle(.black)
                                                            .position(x: 155, y: 60)
                                                        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. ")
                                                            .frame(width: 300, height: 250, alignment: .topLeading)
                                                            .foregroundStyle(.black)
                                                            .position(x:175, y:80)
                                                        Image(systemName: "plus")
                                                            .resizable()
                                                            .bold()
                                                            .frame(width: 15, height: 15, alignment: .topLeading)
                                                            .foregroundColor(.black)
                                                            .position(x: 315, y:-148)
                                                    }
                                                )
                                        }
                                    }
                                    
                                )
                                .onTapGesture{
                                    isOverlay = false
                                }
                            
                        }
                    }
                }
                .frame(height: 500, alignment: .center)
                .position(x: 196, y:440)
                
            }
            //.edgesIgnoringSafeArea(.top)
            
        }
    }

}

struct UserPage_Previews: PreviewProvider{
    static var previews: some View{
        UserPage()
            .environmentObject(SharedData())
    }
}

