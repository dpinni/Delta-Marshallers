//
//  SharedData.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/14/24.
//

    //friends page
    // search page
    // pro picutre b/w signup
    // filter enters post signup
    //
//  to do post break

import SwiftUI

class SharedData: ObservableObject {
    @Published var fullName = ""
    @Published var userName = ""
    @Published var password1 = ""
    @Published var password2 = ""
    @Published var email = ""
    @Published var birthDate = ""
    @Published var orgName = ""
    @Published var orgType = ""
}

struct DataView: View{
    @EnvironmentObject var userData: SharedData
    
    var body: some View{
        Text("")
    }
}


