//
//  QRView.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 4/9/24.
//

import SwiftUI

struct QRView: View {
    let backgroundColor: Color = .init(white: 0.7)
    @EnvironmentObject var userData: SharedData
    
    var body: some View {
        VStack{
            TabsLayoutView()
                .padding()
                .background(
                    Capsule()
                        .fill(.white)
                )
                .frame(width: 275, height:70)
                .shadow(radius: 20)
                .position(x: 195, y: 650)
            
            if (userData.isMyQR){
                Image("qrCode")
                    .position(x: 195, y: -50)
                    
            } else {
                Text("camera appears here")
            }
        }
    }
    
    
    
}

private struct TabsLayoutView: View {
    //@EnvironmentObject var userData: SharedData
    @State var selectedTab: Tab = .scanCode
    @Namespace var namespace
    
    var body: some View{
        HStack{
            ForEach(Tab.allCases) { tab in
                TabButton(tab: tab, selectedTab: $selectedTab, namespace: namespace)
            }
        }
    }
    
    private struct TabButton: View {
        @EnvironmentObject var userData: SharedData
        let tab: Tab
        @Binding var selectedTab: Tab
        var namespace: Namespace.ID
        @State private var selectedOffset: CGFloat = 0
        @State private var rotationAngle: CGFloat = 0
        
        var body: some View {
            Button {
                withAnimation(.easeInOut){
                    selectedTab = tab
                    if (selectedTab == .scanCode){
                        userData.isMyQR = false
                    } else {
                        userData.isMyQR = true
                    }
                }
                
                selectedOffset = -60
                if tab < selectedTab {
                    rotationAngle += 360
                } else {
                    rotationAngle -= 360
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3){
                    selectedOffset = 0
                    if tab < selectedTab {
                        rotationAngle += 720
                    } else {
                        rotationAngle -= 720
                    }
                }
            } label: {
                ZStack {
                    if isSelected {
                        Capsule()
                            .fill(tab.color.opacity(0.2))
                            .matchedGeometryEffect(id: "Selected Tab", in: namespace)
                    }
                    HStack(spacing: 10){
                        Image(tab.icon)
                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                            .foregroundColor(isSelected ? tab.color : .black.opacity(0.6))
                            .rotationEffect(.degrees(rotationAngle))
                            .scaleEffect(isSelected ? 1 : 0.9)
                            .animation(.easeInOut, value: rotationAngle)
                            .opacity(isSelected ? 1 : 0.7)
                            .padding(.leading, isSelected ? 20 : 0)
                            .padding(.horizontal, selectedTab != tab ? 10 : 0)
                            .offset(y: selectedOffset)
                            .animation(.default, value: selectedOffset)
                        
                        if isSelected {
                            Text(tab.title)
                                .font(.system(size: 20, weight: .semibold, design: .rounded))
                                .foregroundColor(tab.color)
                                .padding(.trailing, 20)
                        }
                    }
                    .padding(.vertical, 10)
                }
            }
            .buttonStyle(.plain)
        }
        
        private var isSelected: Bool {
            selectedTab == tab
        }
    }
}


struct QRView_Previews: PreviewProvider {
    static var previews: some View {
        QRView()
            .environmentObject(SharedData())
    }
}
