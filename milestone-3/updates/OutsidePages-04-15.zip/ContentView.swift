//
//  ContentView.swift
//  SeeUThere2.0
//
//  Created by Nia Michele Dicks on 3/5/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var userData: SharedData
    @State private var selectedTab: Int = 0
    
    var body: some View {
        NavigationStack{
                TabView(selection: $selectedTab) {
                    FriendsPage()
                        .tabItem() {
                            Image("searchIcon")
                            Text ("Friends")
                        }.tag(0)
                    UserPage()
                        .tabItem() {
                            Image("icon")
                        }.tag(1)
                    
                    CalendarView()
                        .tabItem(){
                            Image("calendarIcon")
                            Text ("Calendar")
                        }.tag(2)
                }
                .onAppear{
                    selectedTab = 1;
                }
        } .navigationBarBackButtonHidden(true)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(SharedData())
            
    }
}


enum Tab: Int, Identifiable, CaseIterable, Comparable{
    static func < (lhs: Tab, rhs: Tab) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
    
    case scanCode, getCode
    
    internal var id: Int { rawValue }
    
    var icon: String {
        switch self {
        case .scanCode:
            return "scannerIcon"
        case .getCode:
            return "qrIcon"
        }
    }
    
    var title: String {
        switch self {
        case .scanCode:
            return "Scan QR"
        case .getCode:
            return "My QR"
        }
    }
    
    var color: Color {
        switch self {
        case .scanCode:
            return .black
        case .getCode:
            return .black
        }
    }
}
