//
//  Event_AppApp.swift
//  Event App
//
//  Created by Clare Rizzo on 2/27/24.
//

import SwiftUI

@main
struct Event_AppApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
