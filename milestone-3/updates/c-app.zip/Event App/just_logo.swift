//
//  just_logo.swift
//  Event App
//
//  Created by Clare Rizzo on 3/5/24.
//

import SwiftUI

struct just_logo: View {
    var body: some View {
        Image("logo")
            .resizable()
            .frame(width: 100, height: 100)
            //.opacity(0.3)
            
    }
}

#Preview {
    just_logo()
}
