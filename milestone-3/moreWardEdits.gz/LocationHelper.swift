//
//  LocationHelper.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/12/24.
//

import SwiftUI

struct LocationHelper: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LocationHelper_Previews: PreviewProvider {
    static var previews: some View {
        LocationHelper()
    }
}
