//
//  mapview.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/12/24.
//

import MapKit
import SwiftUI

public struct MapDefaults {
    static let latitude = 34.6774
    static let longitude = -82.836
    static let zoom = 0.005
}

struct MyMapView: View {
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: MapDefaults.latitude, longitude: MapDefaults.longitude),
        span: MKCoordinateSpan(latitudeDelta: MapDefaults.zoom, longitudeDelta: MapDefaults.zoom))
        

    var body: some View {
        
        VStack {
            Text("lat: \(region.center.latitude), long: \(region.center.longitude). Zoom: \(region.span.latitudeDelta)")
            .font(.caption)
            .padding()
            Map(coordinateRegion: $region,
                interactionModes: .all,
                showsUserLocation: true)
        }
    }
}

struct MyAnnotationItem: Identifiable {
    var coordinate: CLLocationCoordinate2D
    let id = UUID()
}


struct MapView_Previews: PreviewProvider {
    
    let annotationItems = [
        MyAnnotationItem(coordinate: CLLocationCoordinate2D(
            latitude: MapDefaults.latitude,
            longitude: MapDefaults.longitude))]
    
    static var previews: some View {
        
        MyMapView()
    }
}
