//
//  ViewDate.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

struct ViewDate: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ViewDate_Previews: PreviewProvider {
    static var previews: some View {
        ViewDate()
    }
}
