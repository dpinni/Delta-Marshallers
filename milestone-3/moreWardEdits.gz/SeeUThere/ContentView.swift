//
//  ContentView.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

struct ContentView: View {
   //@State private var goToMap
    var body: some View {
        // Added DatePicker with selection equal to State variable selectedDate
        //DatePicker("Select Date", selection:$selectedDate)
          //.padding(.horizontal)
        TabView{
        
            
            CalendarView()
                .tabItem {
                    Label("See Calendar", systemImage: "calendar")
                        .padding()
                    
                };
            
            AddEvent()
                .tabItem{
                    Label("See Calendar", systemImage: "calendar")
                    .padding()}
            
           /* MyMapView()
                .tabItem{
                    Label("Add Location", systemImage: "map")
                        .padding()
                }*/
            
            
        }.onAppear {
            let appearance = UITabBarAppearance()
            appearance.backgroundColor = UIColor(Color.purple.opacity(0.2))
            appearance.shadowColor = UIColor(.purple)
            appearance.backgroundEffect = UIBlurEffect(style: .extraLight)
            UITabBar.appearance().standardAppearance = appearance
            UITabBar.appearance().scrollEdgeAppearance = appearance
            
        }
    }
    
}

func goToAddEventPage(){
     var body: some View{
        AddEvent()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
    

