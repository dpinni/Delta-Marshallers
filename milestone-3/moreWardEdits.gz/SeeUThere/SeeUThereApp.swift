//
//  SeeUThereApp.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

@main
struct SeeUThereApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
