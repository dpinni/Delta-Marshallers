//
//  EKEventEditViewController.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/28/24.
//

/*
import SwiftUI



struct EventEditViewController: UIViewControllerRepresentable {
    
    typealias UIViewControllerType = EKEventEditViewController
    func makeUIViewController(context: Context) -> EKEventEditViewController {
       
    }
    func updateUIViewController(_ uiViewController: EKEventEditViewController, context: Context) {}
}

struct EventEditViewController: UIViewControllerRepresentable {
let ticket: Ticket
   private var event: EKEvent {
       let event = EKEvent(eventStore: store)
       event.title = ticket.title
       if let startDate = ticket.startDate, let endDate = ticket.endDate {
           let startDateComponents = DateComponents(year: startDate.year,
                                                    month: startDate.month,
                                                    day: startDate.day,
                                                    hour: startDate.hour,
                                                    minute: startDate.minute)
           event.startDate = Calendar.current.date(from: startDateComponents)!
           let endDateComponents = DateComponents(year: endDate.year,
                                                    month: endDate.month,
                                                    day: endDate.day,
                                                    hour: endDate.hour,
                                                    minute: endDate.minute)
           event.endDate = Calendar.current.date(from: endDateComponents)!
           event.location = ticket.location
           event.notes = "Don't forget to bring popcorn🍿️!"
       }
       return event
   }
 ...
}


struct EventEditViewController_Previews: PreviewProvider {
    static var previews: some View {
        EventEditViewController()
    }
}
*/
