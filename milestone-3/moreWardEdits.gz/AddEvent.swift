//
//  AddEvent.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

//@StateObject private var manager: DataManagement = DataManagement()

struct AddEvent: View {
    @State private var event: String = "" //important
    @State private var selectedDate: Date = Date() //important
    @State private var price: Double = 0 //important
    @State private var duration: Double = 0 //important
    @State private var isEditing = false
    @State private var location: String = "" //important
    @State private var extraInfo: String = "" //important
    
    
    var body: some View{
        Form{
            /*Event Name*/
            Section{
                Text("Event Name").font(.headline)
                TextField(text: $event, prompt: Text("Enter your Event Name")){
                    Text("EventName")
                }
            }
            Section{
                Text("Date").font(.headline)
                DatePicker("Date and Time", selection: $selectedDate)
                VStack{
                    Text("Duration").font(.headline)
                    Slider(
                        value: $duration,
                            in: 0...300,
                            step: 5,
                            onEditingChanged: { editing in
                                isEditing = editing
                            }
                        )
                    Text("\(Int(duration)) minutes")
                            .foregroundColor(isEditing ? .red : .blue)
                }
            }
            
            Section{
                VStack{
                    Text("Price").font(.headline)
                    Slider(
                            value: $price,
                            in: 0...250,
                            step: 1,
                            onEditingChanged: { editing in
                                isEditing = editing
                            }
                        )
                    Text("$\(Int(price))")
                            .foregroundColor(isEditing ? .red : .blue)
                }
            }
            
            Section{
                Text("Event Location").font(.headline)
                TextField(text: $location, prompt: Text("Enter the location of your event")){
                    Text("EventLocation")
                }
            }
            
            Section{
                Text("Additional information").font(.headline)
                TextField(text: $extraInfo, prompt: Text("Enter the Additional event about your event")){
                    Text("ExtraInfo")
                }
            }
            
            Section{
                sendToNextPage()
                
            }
            
            }
    
        }
    }


struct sendToNextPage: View{
    var body: some View{
        Button(action: submit){
            Text("Submit")
        }
    }
    
    func submit() {
        
        //mapview_Previews.self
    }
}


struct AddEvent_Previews: PreviewProvider {
    
    
    static var previews: some View {
        AddEvent()
    }
}
