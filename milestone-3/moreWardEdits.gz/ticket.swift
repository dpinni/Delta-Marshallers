//
//  ticket.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/28/24.
//

import SwiftUI

struct Ticket: Identifiable {
   var id: UUID = UUID()
   var title: String
   var theater: String
   var location: String
   var start: String
   var end: String
   var image: String
}

struct ticket: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ticket_Previews: PreviewProvider {
    static var previews: some View {
        ticket()
    }
}
