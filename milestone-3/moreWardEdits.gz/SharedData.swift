//
//  SharedData.swift
//  SeeUThere
//
//  Created by Ward Eldred on 4/1/24.
//

import Foundation
import SwiftUI

class plannedEvents: ObservableObject{
    static var event: String = "" //important
    static var selectedDate: Date = Date() //important
    static var price: Double = 0 //important
    static var duration: Double = 0 //important
    static var location: String = "" //important
    static var extraInfo: String = "" //important
    static var type: String = "" //important
    static var dateFormatted = DateFormatter().string(from: selectedDate)
    
    
    func checkData(D: Date) -> Void{
        if(D == selectedDate){
            showEventInfo()
        }
    }
    
}

struct showEventInfo:View{
    var body: some View{
        Section{
            Text("\(plannedEvents.event)").font(.headline)
            Text("$\(plannedEvents.price)")
            Text("\(plannedEvents.dateFormatted)")
            Text("\((plannedEvents.duration/60)) hours")
            Text("\(plannedEvents.location)")
            Text("\(plannedEvents.type)")
            Text("\(plannedEvents.extraInfo)")
        }
    }
