//
//  CalendarView.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

struct CalendarView: View {
    @State var selectedDate: Date = Date()
    //private let store = EKEventStore()
    
    var body: some View{
        VStack() {
            Text(selectedDate.formatted(date: .abbreviated, time: .omitted))
                .font(.system(size: 28))
                .bold()
                .foregroundColor(Color.accentColor)
                .padding()
                .animation(.spring(), value: selectedDate)
                .frame(width: 500)
            /*         Button(action:goToAddEventPage){
             Text("Add Event")
             }.position(x:325, y:65)*/
            
            DatePicker("Select Date", selection: $selectedDate, displayedComponents: [.date])
                .padding(.horizontal)
                .datePickerStyle(.graphical)
            
            

        }
        
    }
}


struct AddEventBtn: View{
    var body: some View{
        Button(action: goToAddEventForm){
            Text("Add Event")
        }
    }
    
    func goToAddEventForm() {
        AddEvent()
        //mapview_Previews.self
    }
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}
