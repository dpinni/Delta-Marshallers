//
//  PlannedEvent.swift
//  SeeUThere
//
//  Created by Ward Eldred on 4/9/24.
//

import SwiftUI

class PlannedEvent: ObservableObject, Identifiable {

    @Published var id: UUID
    @Published var name = ""
    @Published var date: Date
    @Published var type = ""
    @Published var price = 0.0
    @Published var duration = 0.0
    @Published var location = ""
    @Published var description = ""
    
    init( inputName:String, inputDate:Date, inputType:String, inputPrice:Double, inputDuration:Double, inputLocation:String, inputDesc:String ) {
        id=UUID()
        name = inputName
        date = inputDate
        type = inputType
        price = inputPrice
        duration = inputDuration
        location = inputLocation
        description = inputDesc
    }
    
    init(){
        id=UUID()
        name = ""
        date = Date.now
        type = ""
        price = 0.0
        duration = 0.0
        location = ""
        description = ""
    }
    
    func getID() -> UUID{
        return id;
    }
}


struct peDataView: View{
    @EnvironmentObject var userData: PlannedEvent
    
    var body: some View{
        Text("")
    }
}




