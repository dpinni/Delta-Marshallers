//
//  HomePage.swift
//  Event App
//
//  Created by Clare Rizzo on 3/7/24.
//

import SwiftUI

struct HomePage: View {
    var body: some View {
        NavigationStack {
            VStack (alignment: .leading, spacing: 6) {
                Text("Welcome")
                Text("name!")
                    .font(.system(size: 35))
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                Spacer()
                //
            }
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .topLeading)
            .position(x: 350, y: 400)
        } .navigationBarBackButtonHidden(true)
        
    }
}

#Preview {
    HomePage()
}

