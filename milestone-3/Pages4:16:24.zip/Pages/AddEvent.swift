//
//  AddEvent.swift
//  SeeUThere
//
//  Created by Ward Eldred on 3/5/24.
//

import SwiftUI

//@State private var event: String = ""
//@FocusState private var emailFieldIsFocused: Bool = false

/*@State private var Date: String = ""
//@FocusState private var emailFieldIsFocused: Bool = false

@State private var Information: String = ""
//@FocusState private var emailFieldIsFocused: Bool = false

@State private var Price: Int = 0
//@FocusState private var emailFieldIsFocused: Bool = false

@State private var Type: String = ""
//@FocusState private var emailFieldIsFocused: Bool = false

@State private var Location: String = ""
//@FocusState private var emailFieldIsFocused: Bool = false
*/


struct AddEvent: View {
    @EnvironmentObject var userData: SharedData
    @ObservedObject private var plannedEvent = PlannedEvent()

    @State public var isEditing = false

    @State public var eventType: Int = 0


    
    var body: some View{
        Form{
            /*Event Name*/
            Section{
                Text("Event Name").font(.headline)
                TextField(text: $userData.event, prompt: Text("Enter your Event Name")){
                    Text("EventName")
                }
            }
            
            Section{
                Text("Date").font(.headline)
                DatePicker("Date and Time", selection: $userData.selectedDate)
                VStack{
                    Text("Duration").font(.headline)
                    Slider(
                        value: $userData.duration,
                        in: 0...300,
                        step: 5,
                        onEditingChanged: { editing in
                            isEditing = editing
                        }
                    )
                    Text("\(Int(userData.duration)) minutes")
                        .foregroundColor(isEditing ? .red : .blue)
                }
            }
            
            Section{
                VStack{
                    Text("Price").font(.headline)
                    Slider(
                        value: $userData.price,
                            in: 0...250,
                            step: 1,
                            onEditingChanged: { editing in
                                isEditing = editing
                            }
                        )
                    Text("$\(Int(userData.price))")
                            .foregroundColor(isEditing ? .red : .blue)
                }
            }
            Section{

                Text("Type of Event: \(userData.eventTypeOptions[userData.typeInt])" ).font(.headline)
                Picker("Select Event Type", selection: $userData.type){
                    ForEach(userData.eventTypeOptions, id: \.self){ index in
                        Text(index).tag(index)
                    }
                }
            }
            
            Section{
                Text("Event Location").font(.headline)
                TextField(text: $userData.location, prompt: Text("Enter the location of your event")){
                    Text("EventLocation")
                }
            }
            
            Section{
                Text("Additional information").font(.headline)
                TextField(text: $userData.extraInfo, prompt: Text("Enter the Additional event about your event")){
                    Text("ExtraInfo")
                }
            }
            
            Section{
                sendToNextPage()
                
            }
            
            
            }
    
        }
    }

struct sendToNextPage: View{
    @EnvironmentObject var userData: SharedData
    
    var body: some View{

        NavigationStack{
            NavigationLink("Submit", destination: ContentView())
                .foregroundColor(.blue)
        }
        .navigationBarBackButtonHidden(true)
        .onTapGesture {
                submit()
            }
    }
    func submit() {
        let event1: PlannedEvent = PlannedEvent( inputName: userData.event, inputDate: userData.selectedDate, inputType: userData.type, inputPrice: userData.price, inputDuration: userData.duration, inputLocation: userData.location, inputDesc: userData.extraInfo)
        
        userData.events.append(event1)
        
    }
    
}


struct AddEvent_Previews: PreviewProvider {
    
    
    static var previews: some View {
        AddEvent()
            .environmentObject(SharedData())
    }
}




