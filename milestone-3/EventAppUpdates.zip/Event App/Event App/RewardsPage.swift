//
//  RewardsPage.swift
//  Event App
//
//  Created by Clare Rizzo on 3/27/24.
//

import SwiftUI

struct RewardsPage: View {
    var body: some View {
        NavigationStack {
            VStack {
                
                Text("Rewards")
                    .padding(30)
                    .font(.largeTitle)
                    .bold()
                Spacer()
                Text("Scan QR code to earn points!")
                Text("My Rewards")
                    .padding(30)
                    .font(.title)
                    .bold()
                Text("You have 0 Rewards :( ")
                    .frame(width: 300, height: 200)
                    .background(Color.white)
                    .border(Color.green)
                    .position(x: 200, y: 100)
                
                
                Spacer()
                
            }
            
        }
        
    }
}

#Preview {
    RewardsPage()
}
