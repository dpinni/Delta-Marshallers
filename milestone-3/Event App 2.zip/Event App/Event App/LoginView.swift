//
//  ContentView.swift
//  Event App
//
//  Created by Clare Rizzo on 2/27/24.
//

import SwiftUI

struct LoginView: View {
    @State private var email = " "
    @State private var password = " "
    var body: some View {
        NavigationStack {
        VStack{
            logo_login()
        }
        VStack {

                Text("Enter your Username and Password")
                    .font(.title3)
                    .padding(.bottom)
                    
                TextField("Email", text: $email)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(.green.opacity(0.1))
                    .cornerRadius(20.0)
                
                SecureField("Password", text: $password)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(.green.opacity(0.1))
                    .cornerRadius(20.0)
                
            NavigationLink("Login", destination: HomePage())
                    .frame(width: 300, height: 50)
                    .foregroundColor(.white)
                    .background(.green)
                    .cornerRadius(20.0)
            
            // link to page to create new password
            Text("Forgot Password?")
                .font(.subheadline)
                .foregroundColor(.blue)
                .padding(.bottom)
                .underline()
            
                // need to create account
                NavigationLink("Sign Up", destination: SignUpView())
                    .frame(width: UIScreen.main.bounds.size.width / 2.2, height: 50)
                    .foregroundColor(.white)
                    .background(.green)
                    .cornerRadius(20.0)
                    
            }
        }
        .padding()
    }
}

#Preview {
    LoginView()
}
