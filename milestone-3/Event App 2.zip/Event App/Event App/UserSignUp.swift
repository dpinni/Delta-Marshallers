//
//  UserSignUp.swift
//  Event App
//
//  Created by Clare Rizzo on 3/5/24.
//

import SwiftUI

struct UserSignUp: View {
    @State var labelWidth: CGFloat? = nil

    @State var username = ""
    @State var password = ""
    @State var email = ""
    @State var firstName = ""
    @State var lastName = ""
    @State var birthDate = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                just_logo()
                    .padding(50)
            }
            TextField("First Name", text: $firstName)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Last Name", text: $lastName)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Email", text: $email)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Password", text: $password)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Confirm Password", text: $password)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            TextField("Birthdate (MM/DD/YYYY)", text: $birthDate)
                .padding(.horizontal, 30).padding(.top, 20)
                Divider()
                .padding(.horizontal, 30)
            Spacer()
            VStack {
                Spacer()
                NavigationLink("Create", destination: HomePage())
                    
                    .frame(width: 200, height: 50)
                    .foregroundColor(.white)
                    .background(.green)
                    .cornerRadius(20.0)
            }
            
        }
    }
}

#Preview {
    UserSignUp()
}
