//
//  scan_icon.swift
//  Event App
//
//  Created by Clare Rizzo on 3/12/24.
//

import SwiftUI

struct scan_icon: View {
    var body: some View {
        Image("scanIcon")
            .resizable()
            .frame(width: 40, height: 40)
    }
}

#Preview {
    scan_icon()
}
