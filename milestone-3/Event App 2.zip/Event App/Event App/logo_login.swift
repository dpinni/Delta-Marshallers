//
//  logo_login.swift
//  Event App
//
//  Created by Clare Rizzo on 3/5/24.
//

import SwiftUI

struct logo_login: View {
    var body: some View {
        Image("logo_with_words")
            .resizable()
            .frame(width: 300, height: 300)
        
    }
}

#Preview {
    logo_login()
}
